var strings = new Array();
strings['cancel'] = 'Annuller';
strings['accept'] = 'OK';
strings['manual'] = 'Brugervejledning';
strings['latex'] = 'LaTeX';
strings['close'] = 'Close';
strings['minimise'] = 'Minimise';
strings['fullscreen'] = 'Full-screen';