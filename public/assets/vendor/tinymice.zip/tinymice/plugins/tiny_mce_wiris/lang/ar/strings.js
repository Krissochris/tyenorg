var strings = new Array();
strings['cancel'] = 'إلغاء';
strings['accept'] = 'موافق';
strings['manual'] = 'الدليل';
strings['latex'] = 'LaTeX';
strings['close'] = 'Close';
strings['minimise'] = 'Minimise';
strings['fullscreen'] = 'Full-screen';