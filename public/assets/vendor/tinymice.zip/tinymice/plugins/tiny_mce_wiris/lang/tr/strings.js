var strings = new Array();
strings['cancel'] = 'Vazgeç';
strings['accept'] = 'Tamam';
strings['manual'] = 'Kılavuz';
strings['latex'] = 'LaTeX';
strings['close'] = 'Close';
strings['minimise'] = 'Minimise';
strings['fullscreen'] = 'Full-screen';