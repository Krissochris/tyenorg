var strings = new Array();
strings['cancel'] = 'Abbrechen';
strings['accept'] = 'OK';
strings['manual'] = 'Handbuch';
strings['latex'] = 'LaTeX';
strings['close'] = 'Close';
strings['minimise'] = 'Minimise';
strings['fullscreen'] = 'Full-screen';