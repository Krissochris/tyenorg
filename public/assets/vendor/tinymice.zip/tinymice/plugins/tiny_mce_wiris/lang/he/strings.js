var strings = new Array();
strings['cancel'] = 'ביטול';
strings['accept'] = 'אישור';
strings['manual'] = 'מדריך';
strings['latex'] = 'LaTeX';
strings['close'] = 'Close';
strings['minimise'] = 'Minimise';
strings['fullscreen'] = 'Full-screen';