<?php

$lang['jb_blankpage_message'] = "The Upload process had not started, or started, but had not finished yet, or your browser could not reach the remote server.";

/* End of file jbstrings_lang.php */
/* Location: ./application/language/english/jbstrings_lang.php */
